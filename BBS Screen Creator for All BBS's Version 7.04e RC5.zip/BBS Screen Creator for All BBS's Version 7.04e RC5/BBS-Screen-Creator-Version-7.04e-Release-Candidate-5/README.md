# BBS Screen Creator Version 7.04e Release Candidate 5
 A BBS Screen Creator that creates BBS screens from simple ascii drawings
